import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_compass/flutter_compass.dart';
import 'package:google_fonts/google_fonts.dart';

class QiblaCompassScreen extends StatelessWidget {
  const QiblaCompassScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFDF7F2),
      appBar: AppBar(
        title: Text("Qibla Finder",
            style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: const Color(0xFF4A3728),
      ),
      body: StreamBuilder<CompassEvent>(
        stream: FlutterCompass.events,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
                child: Text('Error reading heading: ${snapshot.error}'));
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
                child: CircularProgressIndicator(color: Colors.teal));
          }

          double? direction = snapshot.data?.heading;

          // Agar sensor nahi milta (like on Web/Emulator)
          if (direction == null) {
            return Center(
              child: Text(
                  "Device does not have sensors (Common on Web/Emulators)",
                  style: GoogleFonts.poppins()),
            );
          }

          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "${direction.toInt()}°",
                  style: GoogleFonts.poppins(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Colors.teal[800]),
                ),
                const SizedBox(height: 40),
                SizedBox(
                  width: 300,
                  height: 300,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // Dial
                      Transform.rotate(
                        angle: ((direction) * (math.pi / 180) * -1),
                        child: CustomPaint(
                          size: const Size(300, 300),
                          painter: CompassDialPainter(),
                        ),
                      ),
                      // Static Needle (Points North/Qibla)
                      // Tip: For actual Qibla, you subtract the Qibla angle from direction
                      const Icon(Icons.navigation,
                          size: 100, color: Colors.teal),
                    ],
                  ),
                ),
                const SizedBox(height: 40),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30),
                  child: Text(
                    "Note: Compass works best on real mobile devices with Magnetometer sensors.",
                    textAlign: TextAlign.center,
                    style:
                        GoogleFonts.poppins(fontSize: 12, color: Colors.grey),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// Dial Painter (Same as before)
class CompassDialPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.teal.withOpacity(0.1)
      ..style = PaintingStyle.fill;
    canvas.drawCircle(
        Offset(size.width / 2, size.height / 2), size.width / 2, paint);

    final textPainter = TextPainter(textDirection: TextDirection.ltr);
    final directions = ['N', 'E', 'S', 'W'];
    for (int i = 0; i < 4; i++) {
      textPainter.text = TextSpan(
        text: directions[i],
        style: const TextStyle(
            color: Colors.teal, fontWeight: FontWeight.bold, fontSize: 18),
      );
      textPainter.layout();
      double angle = i * 90 * (math.pi / 180);
      double x = size.width / 2 +
          (size.width / 2 - 30) * math.sin(angle) -
          (textPainter.width / 2);
      double y = size.height / 2 -
          (size.height / 2 - 30) * math.cos(angle) -
          (textPainter.height / 2);
      textPainter.paint(canvas, Offset(x, y));
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}
