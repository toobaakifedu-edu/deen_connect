import 'package:flutter/material.dart';
import '../../data/models/quran_model.dart';
import '../../services/quran_service.dart';
import '../../services/audio_storage_service.dart'; // ✅ Updated to free service
import 'surah_detail_screen.dart';

class SurahListScreen extends StatefulWidget {
  const SurahListScreen({super.key});

  @override
  State<SurahListScreen> createState() => _SurahListScreenState();
}

class _SurahListScreenState extends State<SurahListScreen> {
  // ✅ Using the free AudioStorageService instead of S3
  final AudioStorageService _audioService = AudioStorageService();
  int? _currentlyPlayingIndex; // Tracks which Surah is playing

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFDF7F2),
      appBar: AppBar(
        title: const Text(
          "Holy Quran",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.teal[700],
        foregroundColor: Colors.white,
        actions: [
          // Stop all button in AppBar
          if (_currentlyPlayingIndex != null)
            IconButton(
              icon: const Icon(Icons.stop_circle),
              onPressed: () {
                _audioService.stopAudio();
                setState(() => _currentlyPlayingIndex = null);
              },
            )
        ],
      ),
      body: FutureBuilder<List<SurahModel>>(
        future: QuranService.loadFullQuran(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
                child: CircularProgressIndicator(color: Colors.teal));
          } else if (snapshot.hasError) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error_outline, size: 50, color: Colors.red),
                  const SizedBox(height: 10),
                  Text("Error: ${snapshot.error}"),
                ],
              ),
            );
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("Quran data not found"));
          }

          final surahs = snapshot.data!;

          return ListView.builder(
            padding: const EdgeInsets.symmetric(vertical: 10),
            itemCount: surahs.length,
            itemBuilder: (context, index) {
              final surah = surahs[index];
              bool isPlaying = _currentlyPlayingIndex == index;

              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                elevation: 0.5,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  leading: Container(
                    width: 45,
                    height: 45,
                    decoration: BoxDecoration(
                      color: isPlaying
                          ? Colors.orange.withOpacity(0.1)
                          : Colors.teal.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      "${surah.number}",
                      style: TextStyle(
                        color: isPlaying ? Colors.orange : Colors.teal,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  title: Text(
                    surah.nameEnglish,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Color(0xFF4A3728),
                    ),
                  ),
                  subtitle: Text("${surah.ayahs.length} Ayats"),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // ✅ Play/Stop Audio Button
                      IconButton(
                        icon: Icon(
                          isPlaying
                              ? Icons.stop_circle
                              : Icons.play_circle_fill,
                          color: isPlaying ? Colors.red : Colors.teal[700],
                          size: 32,
                        ),
                        onPressed: () {
                          if (isPlaying) {
                            _audioService.stopAudio();
                            setState(() => _currentlyPlayingIndex = null);
                          } else {
                            // Format: e.g., "001.mp3" for Surah 1
                            String fileName =
                                "${surah.number.toString().padLeft(3, '0')}.mp3";

                            // ✅ Play using the new free service
                            _audioService.playAudio(fileName);
                            setState(() => _currentlyPlayingIndex = index);
                          }
                        },
                      ),
                      const SizedBox(width: 8),
                      Text(
                        surah.nameArabic,
                        style: const TextStyle(
                          fontFamily: 'Uthmanic',
                          fontSize: 20,
                          color: Colors.teal,
                        ),
                      ),
                    ],
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SurahDetailScreen(surah: surah),
                      ),
                    );
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _audioService.stopAudio(); // Stop audio when leaving screen
    super.dispose();
  }
}
