import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
// Agar path ka error aaye toh isey poora likhen:
// import 'package:deen_connect/presentation/screens/hadith_list_screen.dart';
import 'hadith_list_screen.dart';

class HadithCategoryScreen extends StatelessWidget {
  // ✅ Constructor ko const rehne denge, dashboard se const hatana kafi tha
  const HadithCategoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Books ki list aur unke API identifiers
    final List<Map<String, dynamic>> books = [
      {
        "name": "Sahih Bukhari",
        "id": "bukhari",
        "color": Colors.green[700],
        "desc": "Most authentic collection"
      },
      {
        "name": "Sahih Muslim",
        "id": "muslim",
        "color": Colors.blue[700],
        "desc": "Authentic Hadith collection"
      },
      {
        "name": "Sunan an-Nasa'i",
        "id": "nasai",
        "color": Colors.orange[700],
        "desc": "Comprehensive Sunan"
      },
      {
        "name": "Sunan Abi Dawud",
        "id": "abudawud",
        "color": Colors.red[700],
        "desc": "Famous Sunan book"
      },
      {
        "name": "Jami' at-Tirmidhi",
        "id": "tirmidhi",
        "color": Colors.purple[700],
        "desc": "Sunan with commentary"
      },
      {
        "name": "Sunan Ibn Majah",
        "id": "ibnmajah",
        "color": Colors.brown[700],
        "desc": "Part of Al-Kutub al-Sittah"
      },
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFFDF7F2),
      appBar: AppBar(
        title: Text("Hadith Collections",
            style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: const Color(0xFF4A3728),
      ),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: GridView.builder(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 15,
            mainAxisSpacing: 15,
            childAspectRatio: 0.85,
          ),
          itemCount: books.length,
          itemBuilder: (context, index) {
            final book = books[index];
            return GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => HadithListScreen(
                        bookId: book['id'], bookName: book['name']),
                  ),
                );
              },
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withOpacity(0.05), blurRadius: 10)
                  ],
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircleAvatar(
                      backgroundColor:
                          (book['color'] as Color).withOpacity(0.1),
                      radius: 30,
                      child: Icon(Icons.menu_book_rounded,
                          color: book['color'], size: 30),
                    ),
                    const SizedBox(height: 15),
                    Text(book['name'],
                        textAlign: TextAlign.center,
                        style: GoogleFonts.poppins(
                            fontWeight: FontWeight.bold, fontSize: 14)),
                    const SizedBox(height: 5),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: Text(book['desc'],
                          textAlign: TextAlign.center,
                          style: GoogleFonts.poppins(
                              fontSize: 10, color: Colors.grey)),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
