import 'package:flutter/material.dart';
import '../../services/hadith_service.dart';
import '../../data/models/hadith_model.dart';
import 'package:deen_connect/core/theme/app_colors.dart';

class HadithListScreen extends StatelessWidget {
  final String bookId;
  final String bookName;

  // ✅ Constructor updated to receive book details
  const HadithListScreen(
      {super.key, required this.bookId, required this.bookName});

  @override
  Widget build(BuildContext context) {
    final HadithService service = HadithService();

    return Scaffold(
      appBar: AppBar(
        // ✅ Dynamic Title based on selected book
        title: Text(
          bookName,
          style:
              const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: AppColors.primary,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: FutureBuilder<List<Hadith>>(
        // ✅ Calling dynamic fetch function with bookId
        future: service.fetchHadiths(bookId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
                child: CircularProgressIndicator(color: AppColors.primary));
          }
          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Text(
                  "Error: ${snapshot.error}\n\nPlease check your internet connection.",
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
                child: Text("No Hadiths found for this collection."));
          }

          return ListView.builder(
            itemCount: snapshot.data!.length,
            padding: const EdgeInsets.all(12),
            itemBuilder: (context, index) {
              final hadith = snapshot.data![index];
              return Card(
                elevation: 3,
                margin: const EdgeInsets.only(bottom: 16),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15)),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // Arabic Text
                      Text(
                        hadith.textArabic,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Uthmanic',
                          height: 1.8,
                        ),
                        textAlign: TextAlign.right,
                      ),
                      const SizedBox(height: 15),
                      const Divider(),
                      const SizedBox(height: 10),
                      // Translation Logic: Urdu first, if empty then English
                      Text(
                        hadith.textUrdu.isNotEmpty
                            ? hadith.textUrdu
                            : hadith.textEnglish,
                        style: const TextStyle(
                            fontSize: 16, color: Colors.black87),
                        textAlign: TextAlign.left,
                      ),
                      const SizedBox(height: 12),
                      // Hadith Number Tag
                      Align(
                        alignment: Alignment.bottomRight,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: AppColors.primary.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            "Hadith No: ${hadith.hadithNumber}",
                            style: const TextStyle(
                                fontSize: 12, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
