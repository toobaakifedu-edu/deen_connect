import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import '../../data/models/quran_model.dart';

class SurahDetailScreen extends StatelessWidget {
  final SurahModel surah;

  const SurahDetailScreen({super.key, required this.surah});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFDF7F2),
      appBar: AppBar(
        title: Column(
          children: [
            Text(surah.nameEnglish,
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text(surah.nameArabic,
                style: const TextStyle(fontSize: 20, fontFamily: 'Uthmanic')),
          ],
        ),
        centerTitle: true,
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: surah.ayahs.length,
        itemBuilder: (context, index) {
          final ayah = surah.ayahs[index];

          return Container(
            margin: const EdgeInsets.only(bottom: 16),
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(15),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                )
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Header: Ayah Number, Copy & Share
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CircleAvatar(
                      radius: 16,
                      backgroundColor: Colors.teal.withOpacity(0.1),
                      child: Text(
                          "${ayah.number}", // ✅ Fixed: number instead of verse
                          style: const TextStyle(
                              color: Colors.teal,
                              fontSize: 12,
                              fontWeight: FontWeight.bold)),
                    ),
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.copy_outlined,
                              size: 20, color: Colors.teal),
                          onPressed: () {
                            Clipboard.setData(ClipboardData(
                                text: "${ayah.textArabic}\n${ayah.textUrdu}"));
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                  content: Text("Ayat & Translation Copied")),
                            );
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.share_outlined,
                              size: 20, color: Colors.teal),
                          onPressed: () {
                            Share.share(
                                "${ayah.textArabic}\n\n${ayah.textUrdu}\n\n(Surah ${surah.nameEnglish}, Ayat ${ayah.number})");
                          },
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 15),

                // Arabic Text
                Text(
                  ayah.textArabic, // ✅ Fixed: textArabic
                  textAlign: TextAlign.right,
                  style: const TextStyle(
                      fontFamily: 'Uthmanic',
                      fontSize: 28,
                      height: 1.8,
                      color: Color(0xFF2D2D2D)),
                ),

                const Divider(height: 30, thickness: 0.5),

                // Urdu Translation
                Text(
                  ayah.textUrdu, // ✅ Fixed: textUrdu added
                  textAlign: TextAlign.right,
                  style: const TextStyle(
                      fontSize: 18,
                      height: 1.5,
                      color: Colors.black87,
                      fontFamily:
                          'Poppins'), // Agar Urdu font hai to wo use karein
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
