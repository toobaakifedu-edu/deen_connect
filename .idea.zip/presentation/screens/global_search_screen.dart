import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/hadith_service.dart';
import '../../services/quran_service.dart';
import '../../data/models/hadith_model.dart';
import 'package:deen_connect/core/theme/app_colors.dart';

class GlobalSearchScreen extends StatefulWidget {
  const GlobalSearchScreen({super.key});

  @override
  State<GlobalSearchScreen> createState() => _GlobalSearchScreenState();
}

class _GlobalSearchScreenState extends State<GlobalSearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  final HadithService _hadithService = HadithService();

  List<Hadith> _hadithResults = [];
  List<Map<String, dynamic>> _quranResults = [];
  bool _isLoading = false;

  void _performSearch(String query) async {
    final trimmedQuery = query.trim();
    if (trimmedQuery.isEmpty) return;

    setState(() {
      _isLoading = true;
      _hadithResults = [];
      _quranResults = [];
    });

    try {
      // ✅ Quran Search (Local Static Call)
      final quranData = await QuranService.searchQuranLocal(trimmedQuery);

      // ✅ Hadith Search (API Call)
      final hadithData = await _hadithService.searchHadiths(trimmedQuery);

      if (mounted) {
        setState(() {
          _quranResults = quranData;
          _hadithResults = hadithData;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Search error occurred. Please try again.")),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: const Color(0xFFFDF7F2),
        appBar: AppBar(
          backgroundColor: AppColors.primary,
          elevation: 0,
          title: TextField(
            controller: _searchController,
            style: const TextStyle(color: Colors.white),
            cursorColor: Colors.white,
            decoration: const InputDecoration(
              hintText: "Search (Sabar, Salah, etc.)",
              hintStyle: TextStyle(color: Colors.white70),
              border: InputBorder.none,
            ),
            onSubmitted: _performSearch,
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.search, color: Colors.white),
              onPressed: () => _performSearch(_searchController.text),
            ),
          ],
          bottom: const TabBar(
            indicatorColor: Colors.white,
            indicatorWeight: 3,
            tabs: [
              Tab(text: "QURAN"),
              Tab(text: "HADITH"),
            ],
          ),
        ),
        body: _isLoading
            ? const Center(
                child: CircularProgressIndicator(color: AppColors.primary))
            : TabBarView(
                children: [
                  _buildQuranList(),
                  _buildHadithList(),
                ],
              ),
      ),
    );
  }

  Widget _buildQuranList() {
    if (_quranResults.isEmpty) return _buildEmptyState();

    return ListView.builder(
      itemCount: _quranResults.length,
      padding: const EdgeInsets.all(12),
      itemBuilder: (context, index) {
        final item = _quranResults[index];
        return Card(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "${item['surahName']} : ${item['ayahNumber']}",
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.brown),
                    ),
                    Text(
                      item['surahArabic'] ?? "",
                      style: GoogleFonts.amiri(
                          color: AppColors.primary, fontSize: 18),
                    ),
                  ],
                ),
                const Divider(height: 20),
                Text(
                  item['arabic'] ?? "",
                  textAlign: TextAlign.right,
                  style: GoogleFonts.amiri(fontSize: 22, height: 1.6),
                ),
                const SizedBox(height: 12),
                Text(
                  item['urdu'] ?? "",
                  textAlign: TextAlign.right,
                  style:
                      GoogleFonts.notoNastaliqUrdu(fontSize: 15, height: 2.0),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildHadithList() {
    if (_hadithResults.isEmpty) return _buildEmptyState();

    return ListView.builder(
      itemCount: _hadithResults.length,
      padding: const EdgeInsets.all(12),
      itemBuilder: (context, index) {
        final hadith = _hadithResults[index];
        return Card(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  hadith.textArabic,
                  textAlign: TextAlign.right,
                  style: GoogleFonts.amiri(
                      fontSize: 20, height: 1.5, fontWeight: FontWeight.bold),
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 10),
                  child: Divider(),
                ),
                Text(
                  hadith.textUrdu.isNotEmpty
                      ? hadith.textUrdu
                      : hadith.textEnglish,
                  style: const TextStyle(fontSize: 14, height: 1.5),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.search_off, size: 80, color: Colors.grey[300]),
          const SizedBox(height: 16),
          const Text("No results found",
              style: TextStyle(color: Colors.grey, fontSize: 16)),
        ],
      ),
    );
  }
}
