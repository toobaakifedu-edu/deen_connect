import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/material.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _notificationsPlugin =
      FlutterLocalNotificationsPlugin();
  static final AudioPlayer _audioPlayer = AudioPlayer();

  // Dashboard par button show/hide karne ke liye
  static ValueNotifier<bool> isAlarmPlaying = ValueNotifier<bool>(false);

  static Future<void> init() async {
    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const InitializationSettings settings =
        InitializationSettings(android: androidSettings);
    await _notificationsPlugin.initialize(settings);
  }

  static Future<void> playNamazAlarm() async {
    try {
      if (isAlarmPlaying.value) return;

      await _audioPlayer.play(AssetSource('sounds/azan_short.mp3'));
      isAlarmPlaying.value = true;

      // 1 minute baad auto stop
      Future.delayed(const Duration(minutes: 1), () {
        if (isAlarmPlaying.value) {
          stopAlarm();
        }
      });
    } catch (e) {
      debugPrint("Error playing audio: $e");
    }
  }

  // Dashboard par error isi function ki wajah se aa raha tha
  static void stopAlarm() async {
    try {
      await _audioPlayer.stop();
      isAlarmPlaying.value = false;
      debugPrint("Alarm Stopped Successfully");
    } catch (e) {
      debugPrint("Error stopping alarm: $e");
    }
  }

  static Future<void> showNotification(String title, String body) async {
    const AndroidNotificationDetails androidDetails =
        AndroidNotificationDetails(
      'namaz_alerts',
      'Namaz Notifications',
      importance: Importance.max,
      priority: Priority.high,
    );

    const NotificationDetails details =
        NotificationDetails(android: androidDetails);

    await _notificationsPlugin.show(0, title, body, details);
    playNamazAlarm();
  }
}
