import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import '../data/local/sqflite_helper.dart';

class SyncService {
  final SqfliteService _sqfService = SqfliteService();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> syncLocalDataToCloud(String userId) async {
    // Internet connection check karein
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.none) return;

    try {
      final db = await _sqfService.database;

      // Wo data nikalain jo sync nahi hua (is_synced = 0)
      final List<Map<String, dynamic>> unsyncedData = await db.query(
        'history',
        where: 'is_synced = ?',
        whereArgs: [0],
      );

      if (unsyncedData.isNotEmpty) {
        for (var row in unsyncedData) {
          // Firestore mein save karein
          await _firestore
              .collection('users')
              .doc(userId)
              .collection('history')
              .doc(row['id'].toString()) // ID barkarar rakhein
              .set({
            'task_name': row['task_name'],
            'timestamp': row['timestamp'],
            'status': row['status'],
            'synced_at': FieldValue.serverTimestamp(),
          });

          // Sqflite mein update kar dein ke sync ho gaya hai
          await db.update(
            'history',
            {'is_synced': 1},
            where: 'id = ?',
            whereArgs: [row['id']],
          );
        }
        print("✅ Sync Success: ${unsyncedData.length} items synced.");
      }
    } catch (e) {
      print("❌ Sync Error: $e");
    }
  }
}
