import 'package:adhan/adhan.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter/foundation.dart';
import 'package:workmanager/workmanager.dart'; // ✅ Added

class PrayerService {
  Future<PrayerTimes?> getPrayerTimes() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return null;

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) return null;
      }

      Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.low);

      final coordinates = Coordinates(position.latitude, position.longitude);
      final params = CalculationMethod.karachi.getParameters();
      params.madhab = Madhab.hanafi;

      final prayerTimes = PrayerTimes.today(coordinates, params);

      // ✅ Har Namaz ke liye Azan schedule karein
      _scheduleAllAzans(prayerTimes);

      return prayerTimes;
    } catch (e) {
      debugPrint("Error fetching prayer times: $e");
      return null;
    }
  }

  // ✅ Sabhi Namazon ko schedule karne wala function
  void _scheduleAllAzans(PrayerTimes pt) {
    _scheduleSingleAzan("Fajr", pt.fajr);
    _scheduleSingleAzan("Dhuhr", pt.dhuhr);
    _scheduleSingleAzan("Asr", pt.asr);
    _scheduleSingleAzan("Maghrib", pt.maghrib);
    _scheduleSingleAzan("Isha", pt.isha);
  }

  void _scheduleSingleAzan(String name, DateTime time) {
    final now = DateTime.now();
    final delay = time.difference(now);

    // Agar namaz ka waqt abhi aana baqi hai (future mein hai)
    if (!delay.isNegative) {
      Workmanager().registerOneOffTask(
        "azan_task_$name", // Unique ID har namaz ke liye
        "play_azan_task", // Ye wahi name hai jo main.dart mein dispatcher handle karega
        initialDelay: delay,
        constraints: Constraints(
          networkType: NetworkType.not_required,
          requiresBatteryNotLow: false,
          requiresCharging: false,
        ),
      );
      debugPrint("Scheduled $name Azan with delay of: ${delay.inMinutes} mins");
    }
  }
}
