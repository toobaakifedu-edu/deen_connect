import 'package:device_calendar/device_calendar.dart';
import 'package:flutter/foundation.dart';
import 'package:timezone/timezone.dart' as tz;

class CalendarService {
  final DeviceCalendarPlugin _deviceCalendarPlugin = DeviceCalendarPlugin();

  /// User ke device calendar mein Tasbeeh reminder add karne ke liye
  Future<void> addTasbeehEvent({
    required String tasbeehName,
    required int targetCount,
    required String targetType,
    required DateTime startDate,
  }) async {
    if (kIsWeb) {
      debugPrint('Calendar is not supported on Web.');
      return;
    }

    try {
      // 1. Check aur Request Permissions
      var permissions = await _deviceCalendarPlugin.hasPermissions();
      if (permissions.isSuccess && !permissions.data!) {
        permissions = await _deviceCalendarPlugin.requestPermissions();
        if (!permissions.isSuccess || !permissions.data!) {
          debugPrint("Calendar permission denied by user.");
          return;
        }
      }

      // 2. Device ke calendars ki list lein (Google, Outlook, Local etc)
      final calendarsResult = await _deviceCalendarPlugin.retrieveCalendars();
      if (!calendarsResult.isSuccess || calendarsResult.data!.isEmpty) {
        debugPrint("No calendars found on this device.");
        return;
      }

      // 3. Pehla valid calendar choose karein (Aam tor par primary calendar)
      final calendarId = calendarsResult.data!
          .firstWhere((cal) => cal.isReadOnly == false,
              orElse: () => calendarsResult.data!.first)
          .id;

      // 4. Event create karein
      final event = Event(
        calendarId,
        title: 'Tasbeeh: $tasbeehName',
        description:
            'Target: $targetCount $targetType\nReminder from Deen Connect',
        start: tz.TZDateTime.from(startDate, tz.local),
        end: tz.TZDateTime.from(
            startDate.add(const Duration(minutes: 30)), tz.local),
      );

      // 5. Calendar mein save karein
      final result = await _deviceCalendarPlugin.createOrUpdateEvent(event);

      if (result!.isSuccess) {
        debugPrint('Tasbeeh added to device calendar!');
      } else {
        debugPrint(
            'Failed to add event: ${result.errors.map((e) => e.errorMessage)}');
      }
    } catch (e) {
      debugPrint('Error: $e');
    }
  }
}
