import 'package:dio/dio.dart';
import 'dart:convert';
import '../data/local/sqflite_helper.dart';

class DomainApiService {
  // Aapki Domain ka link
  static const String baseUrl = "https://ahmeii.online/api";

  // Credentials (Inko encode karke bhejte hain security ke liye)
  final String _username = "ahmeii.online";
  final String _password = ")[i~UYdxfYn9";

  final Dio _dio = Dio(BaseOptions(
    baseUrl: baseUrl,
    connectTimeout: const Duration(seconds: 10),
  ));

  // Domain se data fetch karne ka function
  Future<void> fetchDailyContent() async {
    try {
      // Basic Auth Header banana
      String auth =
          'Basic ' + base64Encode(utf8.encode('$_username:$_password'));

      final response = await _dio.get("/get-content",
          options: Options(headers: {'Authorization': auth}));

      if (response.statusCode == 200) {
        // Data Sqflite mein save karna
        await SqfliteService()
            .saveHistory(response.data['title'] ?? "New Update", "Domain Sync");
        print("✅ Data fetched from ahmeii.online");
      }
    } catch (e) {
      print("❌ Domain Connection Error: $e");
    }
  }
}
