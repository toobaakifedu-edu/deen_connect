import 'package:audioplayers/audioplayers.dart';

class AudioStorageService {
  final AudioPlayer _player = AudioPlayer();

  // ✅ Yeh ek behtareen free server hai jo hamesha chalta hai
  static const String _remoteUrl = "https://server8.mp3quran.net/afs";

  Future<void> playAudio(String fileName) async {
    try {
      // FileName example: "001.mp3"
      String finalUrl = "$_remoteUrl/$fileName";

      await _player.play(UrlSource(finalUrl));
      print("✅ Playing: $finalUrl");
    } catch (e) {
      print("❌ Audio Error: $e");
    }
  }

  void stopAudio() => _player.stop();
}
