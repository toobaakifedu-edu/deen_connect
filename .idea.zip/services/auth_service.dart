import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // 1. Login Function
  Future<String?> login(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      return "Success";
    } on FirebaseAuthException catch (e) {
      return e.message; // Error message return karega (e.g. Wrong Password)
    } catch (e) {
      return e.toString();
    }
  }

  // 2. Signup Function (Mene isay sahi se format kar diya hai)
  Future<String?> signUp(String email, String password) async {
    try {
      await _auth.createUserWithEmailAndPassword(
          email: email, password: password);
      return "Success";
    } on FirebaseAuthException catch (e) {
      // Maslan: "The email address is already in use"
      return e.message;
    } catch (e) {
      return e.toString();
    }
  }

  // 3. Logout Function (Zaroori hota hai)
  Future<void> signOut() async {
    await _auth.signOut();
  }

  // 4. Current User Check (Check karne ke liye ke koi login hai ya nahi)
  User? get currentUser => _auth.currentUser;
}
