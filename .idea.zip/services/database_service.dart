import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class DatabaseService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final String? uid = FirebaseAuth.instance.currentUser?.uid;

  // 1. Purana count wapas mangwane ke liye
  Future<int> getTasbeehCount() async {
    if (uid != null) {
      var doc = await _db.collection('users').doc(uid).get();
      // Yahan 'total_tasbeeh' use kiya hai taake consistency rahe
      return doc.data()?['total_tasbeeh'] ?? 0;
    }
    return 0;
  }

  // 2. Naya function jo aapne manga: Zikr aur History dono save karne ke liye
  Future<void> saveZikrRecord(String zikrName, int count) async {
    if (uid != null && count > 0) {
      // Step A: History collection mein naya record add karna
      await _db.collection('users').doc(uid).collection('history').add({
        'zikrName': zikrName,
        'count': count,
        'timestamp': FieldValue.serverTimestamp(),
      });

      // Step B: Total count ko update karna (Purani total mein naya count jama karna)
      await _db.collection('users').doc(uid).set({
        'total_tasbeeh': FieldValue.increment(count),
        'last_updated': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    }
  }

  // 3. Simple update (Agar kabhi direct set karna ho)
  Future<void> updateTasbeehCount(int count) async {
    if (uid != null) {
      await _db.collection('users').doc(uid).set({
        'total_tasbeeh': count,
        'last_updated': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    }
  }
}
