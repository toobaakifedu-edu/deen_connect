import 'dart:convert';
import 'package:flutter/services.dart';
import '../data/models/quran_model.dart';

class QuranService {
  // ✅ Surah Metadata (114 Surahs complete)
  static const List<Map<String, String>> _surahMetadata = [
    {"en": "Al-Fatiha", "ar": "الفاتحة"},
    {"en": "Al-Baqarah", "ar": "البقرة"},
    {"en": "Al-Imran", "ar": "آل عمران"},
    {"en": "An-Nisa", "ar": "النساء"},
    {"en": "Al-Ma'idah", "ar": "المائدة"},
    {"en": "Al-An'am", "ar": "الأنعام"},
    {"en": "Al-A'raf", "ar": "الأعراف"},
    {"en": "Al-Anfal", "ar": "الأنفال"},
    {"en": "At-Tawbah", "ar": "التوبة"},
    {"en": "Yunus", "ar": "يونس"},
    {"en": "Hud", "ar": "هود"},
    {"en": "Yusuf", "ar": "يوسف"},
    {"en": "Ar-Ra'd", "ar": "الرعد"},
    {"en": "Ibrahim", "ar": "إبراهيم"},
    {"en": "Al-Hijr", "ar": "الحجر"},
    {"en": "An-Nahl", "ar": "النحل"},
    {"en": "Al-Isra", "ar": "الإسراء"},
    {"en": "Al-Kahf", "ar": "الكهف"},
    {"en": "Maryam", "ar": "مريم"},
    {"en": "Ta-Ha", "ar": "طه"},
    {"en": "Al-Anbiya", "ar": "الأنبياء"},
    {"en": "Al-Hajj", "ar": "الحج"},
    {"en": "Al-Mu'minun", "ar": "المؤمنون"},
    {"en": "An-Nur", "ar": "النور"},
    {"en": "Al-Furqan", "ar": "الفرقان"},
    {"en": "Ash-Shu'ara", "ar": "الشعراء"},
    {"en": "An-Naml", "ar": "النمل"},
    {"en": "Al-Qasas", "ar": "القصص"},
    {"en": "Al-Ankabut", "ar": "العنكبوت"},
    {"en": "Ar-Rum", "ar": "الروم"},
    {"en": "Luqman", "ar": "لقمان"},
    {"en": "As-Sajdah", "ar": "السجدة"},
    {"en": "Al-Ahzab", "ar": "الأحزاب"},
    {"en": "Saba", "ar": "سبأ"},
    {"en": "Fatir", "ar": "فاطر"},
    {"en": "Ya-Sin", "ar": "يس"},
    {"en": "As-Saffat", "ar": "الصافات"},
    {"en": "Sad", "ar": "ص"},
    {"en": "Az-Zumar", "ar": "الزمر"},
    {"en": "Ghafir", "ar": "غافر"},
    {"en": "Fussilat", "ar": "فصلت"},
    {"en": "Ash-Shura", "ar": "الشورى"},
    {"en": "Az-Zukhruf", "ar": "الزخرف"},
    {"en": "Ad-Dukhan", "ar": "الدخان"},
    {"en": "Al-Jathiyah", "ar": "الجاثية"},
    {"en": "Al-Ahqaf", "ar": "الأحقاف"},
    {"en": "Muhammad", "ar": "محمد"},
    {"en": "Al-Fath", "ar": "الفتح"},
    {"en": "Al-Hujurat", "ar": "الحجرات"},
    {"en": "Qaf", "ar": "ق"},
    {"en": "Adh-Dhariyat", "ar": "الذاريات"},
    {"en": "At-Tur", "ar": "الطور"},
    {"en": "An-Najm", "ar": "النجم"},
    {"en": "Al-Qamar", "ar": "القمر"},
    {"en": "Ar-Rahman", "ar": "الرحمن"},
    {"en": "Al-Waqi'ah", "ar": "الواقعة"},
    {"en": "Al-Hadid", "ar": "الحديد"},
    {"en": "Al-Mujadila", "ar": "المجادلة"},
    {"en": "Al-Hashr", "ar": "الحشر"},
    {"en": "Al-Mumtahanah", "ar": "الممتحنة"},
    {"en": "As-Saff", "ar": "الصف"},
    {"en": "Al-Jumu'ah", "ar": "الجمعة"},
    {"en": "Al-Munafiqun", "ar": "المنافقون"},
    {"en": "At-Taghabun", "ar": "التغابن"},
    {"en": "At-Talaq", "ar": "الطلاق"},
    {"en": "At-Tahrim", "ar": "التحريم"},
    {"en": "Al-Mulk", "ar": "الملک"},
    {"en": "Al-Qalam", "ar": "القلم"},
    {"en": "Al-Haqqah", "ar": "الحاقة"},
    {"en": "Al-Ma'arij", "ar": "المعارج"},
    {"en": "Nuh", "ar": "نوح"},
    {"en": "Al-Jinn", "ar": "الجن"},
    {"en": "Al-Muzzammil", "ar": "المزمل"},
    {"en": "Al-Muddathir", "ar": "المدثر"},
    {"en": "Al-Qiyamah", "ar": "القيامة"},
    {"en": "Al-Insan", "ar": "الإنسان"},
    {"en": "Al-Mursalat", "ar": "المرسلات"},
    {"en": "An-Naba", "ar": "النبأ"},
    {"en": "An-Nazi'at", "ar": "النازعات"},
    {"en": "Abasa", "ar": "عبس"},
    {"en": "At-Takwir", "ar": "التكوير"},
    {"en": "Al-Infitar", "ar": "الانفطار"},
    {"en": "Al-Mutaffifin", "ar": "المطففين"},
    {"en": "Al-Inshiqaq", "ar": "الانشقاق"},
    {"en": "Al-Buruj", "ar": "البروج"},
    {"en": "At-Tariq", "ar": "الطارق"},
    {"en": "Al-A'la", "ar": "الأعلى"},
    {"en": "Al-Ghashiyah", "ar": "الغاشية"},
    {"en": "Al-Fajr", "ar": "الفجر"},
    {"en": "Al-Balad", "ar": "البلد"},
    {"en": "Ash-Shams", "ar": "الشمس"},
    {"en": "Al-Layl", "ar": "الليل"},
    {"en": "Ad-Duha", "ar": "الضحى"},
    {"en": "Ash-Sharh", "ar": "الشرح"},
    {"en": "At-Tin", "ar": "التين"},
    {"en": "Al-Alaq", "ar": "العلق"},
    {"en": "Al-Qadr", "ar": "القدر"},
    {"en": "Al-Bayyinah", "ar": "البينة"},
    {"en": "Az-Zalzalah", "ar": "الزلزلة"},
    {"en": "Al-Adiyat", "ar": "العاديات"},
    {"en": "Al-Qari'ah", "ar": "القارعة"},
    {"en": "At-Takathur", "ar": "التكاثر"},
    {"en": "Al-Asr", "ar": "العصر"},
    {"en": "Al-Humazah", "ar": "الهمزة"},
    {"en": "Al-Fil", "ar": "الفیل"},
    {"en": "Quraysh", "ar": "قريش"},
    {"en": "Al-Ma'un", "ar": "الماعون"},
    {"en": "Al-Kawthar", "ar": "الكوثر"},
    {"en": "Al-Kafirun", "ar": "الكافرون"},
    {"en": "An-Nasr", "ar": "النصر"},
    {"en": "Al-Masad", "ar": "المسد"},
    {"en": "Al-Ikhlas", "ar": "الإخلاص"},
    {"en": "Al-Falaq", "ar": "الفلق"},
    {"en": "An-Nas", "ar": "الناس"}
  ];

  static Future<List<SurahModel>> loadFullQuran() async {
    try {
      final String response =
          await rootBundle.loadString('assets/data/quran.json');
      final Map<String, dynamic> data = json.decode(response);
      List<SurahModel> allSurahs = [];

      data.forEach((key, value) {
        int index = int.parse(key);
        // Map current JSON to AyahModel
        List<AyahModel> ayahs =
            (value as List).map((item) => AyahModel.fromJson(item)).toList();

        allSurahs.add(SurahModel(
          number: index,
          ayahs: ayahs,
          // index-1 safety: array zero-based hota hai
          nameEnglish: _surahMetadata[index - 1]['en'] ?? "Unknown",
          nameArabic: _surahMetadata[index - 1]['ar'] ?? "Unknown",
        ));
      });

      allSurahs.sort((a, b) => a.number.compareTo(b.number));
      return allSurahs;
    } catch (e) {
      print("Error loading Quran data: $e");
      return [];
    }
  }

  static Future<List<Map<String, dynamic>>> searchQuranLocal(
      String query) async {
    if (query.trim().isEmpty) return [];

    try {
      List<SurahModel> allSurahs = await loadFullQuran();
      List<Map<String, dynamic>> searchResults = [];
      String q = query.toLowerCase().trim();

      for (var surah in allSurahs) {
        for (var ayah in surah.ayahs) {
          // ✅ AyahModel ke correct names use kiye hain
          String urduText = ayah.textUrdu.toLowerCase();
          String arabicText = ayah.textArabic;

          if (urduText.contains(q) || arabicText.contains(q)) {
            searchResults.add({
              "surahName": surah.nameEnglish,
              "surahArabic": surah.nameArabic,
              "ayahNumber": ayah.number,
              "arabic": arabicText,
              "urdu": ayah.textUrdu,
            });
          }
        }
      }
      return searchResults;
    } catch (e) {
      print("Quran Local Search Error: $e");
      return [];
    }
  }
}
