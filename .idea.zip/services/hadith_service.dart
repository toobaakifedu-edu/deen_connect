import 'dart:convert';
import 'package:http/http.dart' as http;
import '../data/models/hadith_model.dart';
import 'package:flutter/foundation.dart';

class HadithService {
  // Base URL for Sunnah.com API
  final String _baseUrl = 'https://api.sunnah.com/v1';

  // ✅ 1. Specific book fetch karne ke liye (Existing)
  Future<List<Hadith>> fetchHadiths(String bookId) async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/collections/$bookId/hadiths?limit=50&page=1'),
        headers: {
          'Accept': 'application/json',
          // 'X-API-Key': 'YOUR_API_KEY_HERE',
        },
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        List hadithList = data['data'] ?? [];
        return hadithList.map((item) => Hadith.fromJson(item)).toList();
      } else {
        throw Exception(
            'Failed to load $bookId. Status: ${response.statusCode}');
      }
    } catch (e) {
      debugPrint("Hadith Fetch Error: $e");
      throw Exception('Connection Error: Internet check karein.');
    }
  }

  // ✅ 2. FIX: Bukhari Hadiths Fetch Method (Jo missing tha)
  Future<List<Hadith>> fetchBukhariHadiths() async {
    // Ye method wahi search logic use karega jo niche hai
    return await searchHadiths("bukhari");
  }

  // ✅ 3. Search Engine (Across all books)
  Future<List<Hadith>> searchHadiths(String query) async {
    if (query.isEmpty) return [];

    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/search?q=${Uri.encodeComponent(query)}'),
        headers: {
          'Accept': 'application/json',
          // 'X-API-Key': 'YOUR_API_KEY_HERE',
        },
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        List results = data['data'] ?? [];
        return results.map((item) => Hadith.fromJson(item)).toList();
      } else {
        debugPrint("Search API Error: ${response.statusCode}");
        return [];
      }
    } catch (e) {
      debugPrint("Global Search Error: $e");
      return [];
    }
  }
}
