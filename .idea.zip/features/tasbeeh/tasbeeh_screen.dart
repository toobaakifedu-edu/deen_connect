import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../data/models/tasbeeh_model.dart';
import '../../services/calendar_service.dart'; // Import your new service

class TasbeehScreen extends StatefulWidget {
  final Tasbeeh tasbeeh;
  const TasbeehScreen({super.key, required this.tasbeeh});

  @override
  State<TasbeehScreen> createState() => _TasbeehScreenState();
}

class _TasbeehScreenState extends State<TasbeehScreen> {
  // Instance of the new service
  final CalendarService _calendarService = CalendarService();

  void _incrementCounter() {
    setState(() {
      if (widget.tasbeeh.currentCount < widget.tasbeeh.targetCount) {
        widget.tasbeeh.currentCount++;
        widget.tasbeeh.save();
        HapticFeedback.lightImpact();
      }
    });
  }

  void _resetCounter() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Reset?"),
        content: const Text("Kya aap isay zero karna chahte hain?"),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Nahi")),
          TextButton(
            onPressed: () {
              setState(() {
                widget.tasbeeh.currentCount = 0;
                widget.tasbeeh.save();
              });
              Navigator.pop(context);
            },
            child: const Text("Haan"),
          ),
        ],
      ),
    );
  }

  // Function to handle Calendar Reminder
  Future<void> _setCalendarReminder() async {
    // Current time se 1 hour baad ka reminder set karte hain
    final reminderTime = DateTime.now().add(const Duration(hours: 1));

    await _calendarService.addTasbeehEvent(
      tasbeehName: widget.tasbeeh.name,
      targetCount: widget.tasbeeh.targetCount,
      targetType: "Total",
      startDate: reminderTime,
    );

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Reminder added to your phone calendar!")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    double progress = widget.tasbeeh.targetCount > 0
        ? widget.tasbeeh.currentCount / widget.tasbeeh.targetCount
        : 0;

    return Scaffold(
      backgroundColor: const Color(0xFFFDF7F2),
      appBar: AppBar(
        title: Text(widget.tasbeeh.name),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: const Color(0xFF4A3728),
        actions: [
          // New Calendar Button
          IconButton(
            icon: const Icon(Icons.calendar_today_outlined),
            tooltip: "Remind Me",
            onPressed: _setCalendarReminder,
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _resetCounter,
          )
        ],
      ),
      body: InkWell(
        onTap: _incrementCounter,
        highlightColor: Colors.transparent,
        splashColor: Color(widget.tasbeeh.colorValue).withOpacity(0.1),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 250,
                    height: 250,
                    child: CircularProgressIndicator(
                      value: progress,
                      strokeWidth: 10,
                      backgroundColor: Colors.grey.shade200,
                      color: Color(widget.tasbeeh.colorValue),
                    ),
                  ),
                  Text("${widget.tasbeeh.currentCount}",
                      style: GoogleFonts.poppins(
                          fontSize: 70, fontWeight: FontWeight.bold)),
                ],
              ),
              const SizedBox(height: 20),
              Text("Target: ${widget.tasbeeh.targetCount}",
                  style: const TextStyle(fontSize: 18, color: Colors.blueGrey)),
              const SizedBox(height: 50),
              const Icon(Icons.touch_app, size: 40, color: Colors.grey),
              const Text("Tap anywhere to count",
                  style: TextStyle(color: Colors.grey)),
            ],
          ),
        ),
      ),
    );
  }
}
