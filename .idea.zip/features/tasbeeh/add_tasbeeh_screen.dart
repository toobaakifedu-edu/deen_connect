import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive_flutter/hive_flutter.dart';
// ✅ Sahi path set kar diya gaya hai
import '../../data/models/tasbeeh_model.dart';

class AddTasbeehScreen extends StatefulWidget {
  const AddTasbeehScreen({super.key});

  @override
  State<AddTasbeehScreen> createState() => _AddTasbeehScreenState();
}

class _AddTasbeehScreenState extends State<AddTasbeehScreen> {
  final _nameController = TextEditingController();
  final _targetController = TextEditingController();

  String _selectedDuration = 'Daily';
  int _selectedColorValue = 0xFF4A3728;

  final List<int> _colors = [
    0xFF4A3728,
    0xFF2E7D32,
    0xFF1565C0,
    0xFFC62828,
    0xFFE65100,
    0xFF6A1B9A,
  ];

  void _saveTasbeeh() async {
    if (_nameController.text.isEmpty || _targetController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please fill all fields!")),
      );
      return;
    }

    final newTasbeeh = Tasbeeh(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: _nameController.text.trim(),
      targetCount: int.tryParse(_targetController.text.trim()) ?? 100,
      startDate: DateTime.now(),
      durationType: _selectedDuration,
      colorValue: _selectedColorValue,
      currentCount: 0,
      isCompleted: false,
    );

    try {
      // ✅ Hive mein save karne ka sahi tareeqa
      var box = Hive.box<Tasbeeh>('tasbeehBox');
      await box.put(newTasbeeh.id, newTasbeeh);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Tasbeeh added successfully!")),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      debugPrint("Error saving tasbeeh: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFDF7F2),
      appBar: AppBar(
        title: Text("Add New Tasbeeh", style: GoogleFonts.poppins()),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildLabel("Tasbeeh Name"),
            TextField(
              controller: _nameController,
              decoration: _inputDecoration("e.g. SubhanAllah"),
            ),
            const SizedBox(height: 20),
            _buildLabel("Target Count"),
            TextField(
              controller: _targetController,
              keyboardType: TextInputType.number,
              decoration: _inputDecoration("e.g. 33, 100"),
            ),
            const SizedBox(height: 30),
            _buildLabel("Select Color"),
            SizedBox(
              height: 50,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _colors.length,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () =>
                        setState(() => _selectedColorValue = _colors[index]),
                    child: Container(
                      margin: const EdgeInsets.only(right: 12),
                      width: 45,
                      decoration: BoxDecoration(
                        color: Color(_colors[index]),
                        shape: BoxShape.circle,
                        border: _selectedColorValue == _colors[index]
                            ? Border.all(color: Colors.black, width: 2)
                            : null,
                      ),
                      child: _selectedColorValue == _colors[index]
                          ? const Icon(Icons.check, color: Colors.white)
                          : null,
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 40),
            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(_selectedColorValue),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: _saveTasbeeh,
                child: const Text("Start Tasbeeh",
                    style: TextStyle(color: Colors.white, fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  InputDecoration _inputDecoration(String hint) {
    return InputDecoration(
      filled: true,
      fillColor: Colors.white,
      hintText: hint,
      border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
    );
  }

  Widget _buildLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child:
          Text(text, style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
    );
  }
}
