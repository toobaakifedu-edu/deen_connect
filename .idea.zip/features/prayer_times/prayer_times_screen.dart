import 'dart:async'; // Timer ke liye
import 'package:flutter/material.dart';
import 'package:deen_connect/core/theme/app_colors.dart';
import 'package:intl/intl.dart';
import 'package:adhan/adhan.dart';
import '../../services/prayer_service.dart';

class PrayerTimesScreen extends StatefulWidget {
  const PrayerTimesScreen({super.key});

  @override
  State<PrayerTimesScreen> createState() => _PrayerTimesScreenState();
}

class _PrayerTimesScreenState extends State<PrayerTimesScreen> {
  final PrayerService _prayerService = PrayerService();
  PrayerTimes? _currentPrayers;
  bool _isLoading = true;
  String _locationName = "Detecting Location...";

  // ✅ Countdown ke liye variables
  Timer? _timer;
  String _timeLeft = "00:00:00";

  @override
  void initState() {
    super.initState();
    _fetchPrayerTimes();
    // ✅ Har second UI update karne ke liye timer
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _updateCountdown();
    });
  }

  @override
  void dispose() {
    _timer?.cancel(); // Memory leak se bachne ke liye
    super.dispose();
  }

  // ✅ Agli Azan tak ka waqt nikalne ka function
  void _updateCountdown() {
    if (_currentPrayers == null) return;

    final now = DateTime.now();
    final nextPrayer = _currentPrayers!.nextPrayer();
    final nextPrayerTime = _currentPrayers!.timeForPrayer(nextPrayer);

    if (nextPrayerTime != null) {
      final difference = nextPrayerTime.difference(now);
      if (difference.isNegative) {
        _fetchPrayerTimes(); // Agar waqt guzar gaya toh refresh karein
      } else {
        if (mounted) {
          setState(() {
            _timeLeft = _formatDuration(difference);
          });
        }
      }
    }
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, "0");
    String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
    String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
    return "${twoDigits(duration.inHours)}:$twoDigitMinutes:$twoDigitSeconds";
  }

  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;
    setState(() => _isLoading = true);

    final times = await _prayerService.getPrayerTimes();

    if (mounted) {
      setState(() {
        _currentPrayers = times;
        _isLoading = false;
        if (times != null) {
          _locationName = "Current Location";
        }
      });
    }
  }

  List<Map<String, dynamic>> _getPrayerList() {
    if (_currentPrayers == null) return [];
    final p = _currentPrayers!;
    final format = DateFormat.jm();

    return [
      {
        'name': 'Fajr',
        'arabic': 'الفجر',
        'time': format.format(p.fajr),
        'color': AppColors.fajrColor,
        'icon': '🌙'
      },
      {
        'name': 'Sunrise',
        'arabic': 'الشروق',
        'time': format.format(p.sunrise),
        'color': AppColors.sunriseColor,
        'icon': '☀️'
      },
      {
        'name': 'Dhuhr',
        'arabic': 'الظهر',
        'time': format.format(p.dhuhr),
        'color': AppColors.dhuhrColor,
        'icon': '☀️'
      },
      {
        'name': 'Asr',
        'arabic': 'العصر',
        'time': format.format(p.asr),
        'color': AppColors.asrColor,
        'icon': '⛅'
      },
      {
        'name': 'Maghrib',
        'arabic': 'المغرب',
        'time': format.format(p.maghrib),
        'color': AppColors.maghribColor,
        'icon': '🌅'
      },
      {
        'name': 'Isha',
        'arabic': 'العشاء',
        'time': format.format(p.isha),
        'color': AppColors.ishaColor,
        'icon': '🌙'
      },
    ];
  }

  @override
  Widget build(BuildContext context) {
    final prayerList = _getPrayerList();
    final nextPrayer = _currentPrayers?.nextPrayer();
    final nextPrayerName = nextPrayer?.name.toUpperCase() ?? "---";

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: AppColors.primary))
          : CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                SliverAppBar(
                  backgroundColor: AppColors.primary,
                  expandedHeight: 200,
                  pinned: true,
                  flexibleSpace: FlexibleSpaceBar(
                    background: Container(
                      decoration: const BoxDecoration(
                          gradient: AppColors.primaryGradient),
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 20, right: 20, top: 80, bottom: 20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Prayer Times',
                                style: TextStyle(
                                    fontSize: 32,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                    fontFamily: 'Poppins')),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                const Icon(Icons.location_on,
                                    color: Colors.white70, size: 18),
                                const SizedBox(width: 6),
                                Expanded(
                                    child: Text(_locationName,
                                        style: const TextStyle(
                                            fontSize: 16,
                                            color: Colors.white70))),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16, vertical: 6),
                                  decoration: BoxDecoration(
                                      color: Colors.white.withOpacity(0.2),
                                      borderRadius: BorderRadius.circular(20)),
                                  child: Text(
                                      DateFormat('dd MMM yyyy')
                                          .format(DateTime.now()),
                                      style: const TextStyle(
                                          fontSize: 14,
                                          color: Colors.white,
                                          fontWeight: FontWeight.w500)),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 20),
                    child: Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                            colors: [Color(0xFF2196F3), Color(0xFF1976D2)]),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                              color: Colors.blue.withOpacity(0.3),
                              blurRadius: 20,
                              spreadRadius: 2)
                        ],
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Next: $nextPrayerName',
                                    style: const TextStyle(
                                        fontSize: 16,
                                        color: Colors.white70,
                                        fontWeight: FontWeight.w500)),
                                const SizedBox(height: 8),
                                // ✅ Countdown Time Display
                                Text(_timeLeft,
                                    style: const TextStyle(
                                        fontSize: 36,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                        fontFamily: 'Poppins')),
                                const SizedBox(height: 12),
                                _buildCountdownChip(),
                              ],
                            ),
                          ),
                          const Text('⛅', style: TextStyle(fontSize: 60)),
                        ],
                      ),
                    ),
                  ),
                ),
                SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (context, index) {
                      final p = prayerList[index];
                      final isCurrent =
                          _currentPrayers?.currentPrayer().name.toLowerCase() ==
                              p['name'].toString().toLowerCase();
                      return Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 8),
                        child: _buildPrayerItem(p, isCurrent),
                      );
                    },
                    childCount: prayerList.length,
                  ),
                ),
                const SliverToBoxAdapter(child: SizedBox(height: 100)),
              ],
            ),
    );
  }

  Widget _buildCountdownChip() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.2),
          borderRadius: BorderRadius.circular(20)),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.notifications_active, size: 14, color: Colors.white),
          SizedBox(width: 6),
          Text('Azan Alerts On',
              style: TextStyle(fontSize: 14, color: Colors.white)),
        ],
      ),
    );
  }

  Widget _buildPrayerItem(Map<String, dynamic> p, bool isCurrent) {
    return Container(
      decoration: BoxDecoration(
        color:
            isCurrent ? (p['color'] as Color).withOpacity(0.1) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border:
            isCurrent ? Border.all(color: p['color'] as Color, width: 2) : null,
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)
        ],
      ),
      child: ListTile(
        leading: Text(p['icon'], style: const TextStyle(fontSize: 28)),
        title: Text(p['name'],
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: isCurrent ? p['color'] : Colors.black87)),
        subtitle: Text(p['arabic'],
            style: const TextStyle(fontSize: 14, color: Colors.grey)),
        trailing: Text(p['time'],
            style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: isCurrent ? p['color'] : Colors.black87)),
      ),
    );
  }
}
