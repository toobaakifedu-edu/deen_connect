import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:adhan/adhan.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:permission_handler/permission_handler.dart';

// Project Imports
import '../../data/models/tasbeeh_model.dart';
import '../tasbeeh/tasbeeh_screen.dart';
import '../tasbeeh/add_tasbeeh_screen.dart';
import '../names/allah_names_screen.dart';
import '../prayer_times/prayer_times_screen.dart';
import '../../presentation/screens/surah_list_screen.dart';
import '../../presentation/screens/hadith_category_screen.dart';
import '../../presentation/screens/global_search_screen.dart';
import 'package:deen_connect/services/notification_service.dart';
import '../qibla/qibla_screen.dart';
// Note: SalahTrackerScreen import removed until file is created

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late Box<Tasbeeh> _tasbeehBox;
  String _filter = 'All';
  int _selectedIndex = 0;

  String _currentCity = "Detecting...";
  PrayerTimes? _prayerTimes;
  bool _isLocating = true;

  String _dailyVerse = "Fetching daily inspiration...";
  String _verseRef = "";
  bool _isLoadingVerse = true;

  @override
  void initState() {
    super.initState();
    _tasbeehBox = Hive.box<Tasbeeh>('tasbeehBox');
    _initLocationAndPrayers();
    _fetchDailyVerse();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _requestNotificationPermission();
    });
  }

  Future<void> _requestNotificationPermission() async {
    var status = await Permission.notification.status;
    if (status.isDenied || status.isLimited) {
      if (mounted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) => AlertDialog(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.notifications_active,
                    size: 50, color: Colors.blueAccent),
                const SizedBox(height: 20),
                Text(
                  "Allow Deen Connect to send you notifications?",
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(
                      fontWeight: FontWeight.bold, fontSize: 18),
                ),
                const SizedBox(height: 10),
                const Divider(),
                TextButton(
                  onPressed: () async {
                    Navigator.pop(context);
                    await Permission.notification.request();
                  },
                  child: const Text("ALLOW",
                      style: TextStyle(
                          color: Colors.blue, fontWeight: FontWeight.bold)),
                ),
                const Divider(),
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: const Text("DON'T ALLOW",
                      style: TextStyle(color: Colors.black54)),
                ),
              ],
            ),
          ),
        );
      }
    }
  }

  Future<void> _fetchDailyVerse() async {
    try {
      final response =
          await http.get(Uri.parse('https://ahmeii.online/api/daily-verse'));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (mounted) {
          setState(() {
            _dailyVerse = data['verse'] ?? "Indeed, with hardship comes ease.";
            _verseRef = data['reference'] ?? "Quran 94:6";
            _isLoadingVerse = false;
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _dailyVerse = "Allah does not burden a soul beyond that it can bear.";
          _verseRef = "Quran 2:286";
          _isLoadingVerse = false;
        });
      }
    }
  }

  Future<void> _initLocationAndPrayers() async {
    try {
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.whileInUse ||
          permission == LocationPermission.always) {
        Position position = await Geolocator.getCurrentPosition(
            desiredAccuracy: LocationAccuracy.low);
        List<Placemark> placemarks = await placemarkFromCoordinates(
            position.latitude, position.longitude);
        final coordinates = Coordinates(position.latitude, position.longitude);
        final params = CalculationMethod.karachi.getParameters();
        final date = DateComponents.from(DateTime.now());
        if (mounted) {
          setState(() {
            _currentCity = placemarks.first.locality ?? "Unknown City";
            _prayerTimes = PrayerTimes(coordinates, date, params);
            _isLocating = false;
          });
        }
      }
    } catch (e) {
      if (mounted) setState(() => _isLocating = false);
    }
  }

  void _onItemTapped(int index) {
    setState(() => _selectedIndex = index);
    Widget? nextScreen;
    switch (index) {
      case 1:
        nextScreen = const SurahListScreen();
        break;
      case 2:
        nextScreen = const QiblaScreen();
        break;
      case 3:
        nextScreen = const PrayerTimesScreen();
        break;
      case 4:
        nextScreen = const AllahNamesScreen();
        break;
    }
    if (nextScreen != null) {
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => nextScreen!));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFDF7F2),
      drawer: _buildSideDrawer(),
      appBar: AppBar(
        title: Text("Deen Connect",
            style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: const Color(0xFF4A3728),
        actions: [
          IconButton(
            icon: const Icon(Icons.search_rounded),
            onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const GlobalSearchScreen())),
          ),
          PopupMenuButton<String>(
            icon:
                const Icon(Icons.filter_list_rounded, color: Color(0xFF4A3728)),
            onSelected: (String value) => setState(() => _filter = value),
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              const PopupMenuItem<String>(
                  value: 'All', child: Text('Show All')),
              const PopupMenuItem<String>(value: 'Daily', child: Text('Daily')),
              const PopupMenuItem<String>(
                  value: 'Monthly', child: Text('Monthly')),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.logout_rounded),
            onPressed: () => FirebaseAuth.instance.signOut(),
          )
        ],
      ),
      bottomNavigationBar: _buildBottomNavBar(),
      body: ValueListenableBuilder(
        valueListenable: _tasbeehBox.listenable(),
        builder: (context, Box<Tasbeeh> box, _) {
          final allTasbeehs = box.values.toList();
          final filteredTasbeehs = allTasbeehs
              .where((t) => _filter == 'All' || t.durationType == _filter)
              .toList();

          return SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildSmartHeader(),
                const SizedBox(height: 20),
                _buildDailyVerseCard(),
                const SizedBox(height: 25),
                Text("Assalam-o-Alaikum,",
                    style: GoogleFonts.poppins(fontSize: 16)),
                const SizedBox(height: 10),
                Text("Islamic Services",
                    style: GoogleFonts.poppins(
                        fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                _buildServicesRow(),
                const SizedBox(height: 30),
                Text("Active Tasbeehs",
                    style: GoogleFonts.poppins(
                        fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                allTasbeehs.isEmpty
                    ? _buildEmptyState()
                    : (filteredTasbeehs.isEmpty
                        ? _noFilterResults()
                        : _buildActiveList(filteredTasbeehs)),
                const SizedBox(height: 30),
                Text("Tasbeeh History",
                    style: GoogleFonts.poppins(
                        fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 5),
                Text("Swipe left to delete",
                    style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                const SizedBox(height: 10),
                _buildHistoryList(filteredTasbeehs),
                const SizedBox(height: 20),
                _actionCard("Create New Tasbeeh", Icons.add_circle, () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const AddTasbeehScreen()));
                }),
                const SizedBox(height: 100),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildBottomNavBar() {
    return Container(
      margin: const EdgeInsets.fromLTRB(15, 0, 15, 20),
      height: 75,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 20,
              offset: const Offset(0, 10))
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: BottomNavigationBar(
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.white,
          selectedItemColor: Colors.teal[800],
          unselectedItemColor: Colors.grey[400],
          showSelectedLabels: true,
          showUnselectedLabels: false,
          elevation: 0,
          items: [
            _buildModernNavIcon(Icons.home_filled, 'Home'),
            _buildModernNavIcon(Icons.menu_book_rounded, 'Quran'),
            _buildModernNavIcon(Icons.explore_rounded, 'Qibla'),
            _buildModernNavIcon(Icons.access_time_filled_rounded, 'Prayers'),
            _buildModernNavIcon(Icons.auto_awesome_mosaic_rounded, 'Names'),
          ],
        ),
      ),
    );
  }

  Widget _buildServicesRow() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      physics: const BouncingScrollPhysics(),
      child: Row(
        children: [
          _serviceCard(
              "Quran",
              Icons.menu_book,
              Colors.teal[600]!,
              () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const SurahListScreen()))),
          const SizedBox(width: 12),
          _serviceCard(
              "Salah Tracker", Icons.checklist_rtl_rounded, Colors.green[700]!,
              () {
            // Navigation commented to resolve compile error
            // Navigator.push(context, MaterialPageRoute(builder: (context) => SalahTrackerScreen()));
          }),
          const SizedBox(width: 12),
          _serviceCard(
              "Hadith",
              Icons.auto_stories,
              Colors.deepPurple[400]!,
              () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const HadithCategoryScreen()))),
          const SizedBox(width: 12),
          _serviceCard(
              "Qibla",
              Icons.explore,
              Colors.orange[700]!,
              () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const QiblaScreen()))),
          const SizedBox(width: 12),
          _serviceCard(
              "Prayer Times",
              Icons.access_time_filled,
              Colors.blue[400]!,
              () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const PrayerTimesScreen()))),
          const SizedBox(width: 12),
          _serviceCard(
              "99 Names",
              Icons.auto_awesome_mosaic,
              Colors.amber[700]!,
              () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const AllahNamesScreen()))),
        ],
      ),
    );
  }

  // ... rest of the helper widgets like _serviceCard, _buildSmartHeader, etc.
  // (Assuming you'll keep the existing UI helpers below)

  Widget _serviceCard(
      String title, IconData icon, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 100,
        padding: const EdgeInsets.symmetric(vertical: 15),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(15),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)
            ]),
        child: Column(children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(height: 8),
          Text(title,
              textAlign: TextAlign.center,
              style: GoogleFonts.poppins(
                  fontSize: 12, fontWeight: FontWeight.w500)),
        ]),
      ),
    );
  }

  Widget _buildSmartHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient:
            LinearGradient(colors: [Colors.teal[700]!, Colors.teal[500]!]),
        borderRadius: BorderRadius.circular(25),
        boxShadow: [
          BoxShadow(
              color: Colors.teal.withOpacity(0.3),
              blurRadius: 15,
              offset: const Offset(0, 8))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(children: [
                const Icon(Icons.location_on, color: Colors.white70, size: 18),
                const SizedBox(width: 5),
                Text(_currentCity,
                    style: GoogleFonts.poppins(
                        color: Colors.white, fontWeight: FontWeight.w500)),
              ]),
              Text(DateFormat('EEEE, d MMM').format(DateTime.now()),
                  style: const TextStyle(color: Colors.white70, fontSize: 12)),
            ],
          ),
          const SizedBox(height: 15),
          _prayerTimes == null
              ? const Center(
                  child: CircularProgressIndicator(color: Colors.white))
              : Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _prayerTimeItem("Fajr", _prayerTimes!.fajr),
                    _prayerTimeItem("Dhuhr", _prayerTimes!.dhuhr),
                    _prayerTimeItem("Asr", _prayerTimes!.asr),
                    _prayerTimeItem("Maghrib", _prayerTimes!.maghrib),
                    _prayerTimeItem("Isha", _prayerTimes!.isha),
                  ],
                ),
        ],
      ),
    );
  }

  Widget _prayerTimeItem(String label, DateTime time) {
    return Column(children: [
      Text(label, style: const TextStyle(color: Colors.white70, fontSize: 10)),
      const SizedBox(height: 4),
      Text(DateFormat.jm().format(time.toLocal()),
          style: const TextStyle(
              color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11)),
    ]);
  }

  Widget _buildDailyVerseCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.teal.withOpacity(0.1))),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.format_quote, color: Colors.teal[300], size: 20),
          Text(" Daily Inspiration",
              style: GoogleFonts.poppins(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.teal[800])),
        ]),
        const SizedBox(height: 10),
        _isLoadingVerse
            ? const SizedBox(
                height: 20,
                width: 20,
                child: CircularProgressIndicator(strokeWidth: 2))
            : Column(children: [
                Text(_dailyVerse,
                    textAlign: TextAlign.center,
                    style: GoogleFonts.poppins(
                        fontSize: 14, fontStyle: FontStyle.italic)),
                const SizedBox(height: 8),
                Text("- $_verseRef",
                    style: GoogleFonts.poppins(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: Colors.teal)),
              ]),
      ]),
    );
  }

  Widget _buildSideDrawer() {
    return Drawer(
      child: Column(children: [
        Container(
          padding: const EdgeInsets.fromLTRB(20, 60, 20, 20),
          color: const Color(0xFF333333),
          width: double.infinity,
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF4CAF50),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8))),
              child: const Text("Login", style: TextStyle(color: Colors.white)),
            ),
            const SizedBox(height: 15),
            const Text("Not a Member",
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 18)),
            const Text("Subscribe for ads free experience",
                style: TextStyle(color: Colors.white70, fontSize: 12)),
          ]),
        ),
        Expanded(
          child: ListView(padding: EdgeInsets.zero, children: [
            _drawerItem(Icons.person_outline, "About Us"),
            _drawerItem(Icons.settings_outlined, "Setting"),
            _drawerItem(Icons.block_outlined, "Remove Ads"),
            _drawerItem(Icons.chat_outlined, "Whatsapp Support"),
            _drawerItem(Icons.notifications_none_outlined, "Notification"),
            _drawerItem(Icons.edit_note_outlined, "Feedback"),
            _drawerItem(Icons.verified_outlined, "Certificates"),
            _drawerItem(Icons.help_outline, "FAQ"),
            const Divider(),
            _drawerItem(Icons.logout_rounded, "Logout", onTap: () {
              FirebaseAuth.instance.signOut();
              Navigator.pop(context);
            }),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.all(15),
          child: Text("Version: 21.0.4",
              style: TextStyle(color: Colors.grey[600], fontSize: 12)),
        ),
      ]),
    );
  }

  Widget _drawerItem(IconData icon, String title, {VoidCallback? onTap}) {
    return ListTile(
      leading: Icon(icon, color: Colors.grey[700]),
      title: Text(title, style: GoogleFonts.poppins(fontSize: 14)),
      onTap: onTap ?? () => Navigator.pop(context),
    );
  }

  BottomNavigationBarItem _buildModernNavIcon(IconData icon, String label) =>
      BottomNavigationBarItem(icon: Icon(icon), label: label);

  Widget _buildActiveList(List<Tasbeeh> list) {
    return SizedBox(
      height: 160,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: list.length,
        itemBuilder: (context, index) {
          final item = list[index];
          return GestureDetector(
            onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => TasbeehScreen(tasbeeh: item))),
            child: Container(
              width: 150,
              margin: const EdgeInsets.only(right: 15),
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                  color: Color(item.colorValue),
                  borderRadius: BorderRadius.circular(20)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.auto_awesome,
                      color: Colors.white70, size: 20),
                  Text(item.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16)),
                  Text("${item.currentCount}/${item.targetCount}",
                      style: const TextStyle(color: Colors.white70)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildHistoryList(List<Tasbeeh> list) {
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: list.length,
      itemBuilder: (context, index) {
        final item = list[index];
        double progress =
            item.targetCount > 0 ? (item.currentCount / item.targetCount) : 0;
        return Dismissible(
          key: Key(item.key.toString()),
          direction: DismissDirection.endToStart,
          onDismissed: (direction) => _tasbeehBox.delete(item.key),
          background: Container(
              alignment: Alignment.centerRight,
              padding: const EdgeInsets.only(right: 20),
              decoration: BoxDecoration(
                  color: Colors.red[400],
                  borderRadius: BorderRadius.circular(15)),
              child: const Icon(Icons.delete, color: Colors.white)),
          child: Card(
            margin: const EdgeInsets.only(bottom: 10),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            child: ListTile(
              leading: CircleAvatar(
                  backgroundColor: Color(item.colorValue), radius: 10),
              title: Text(item.name,
                  style: GoogleFonts.poppins(fontWeight: FontWeight.w500)),
              subtitle: Text("Progress: ${(progress * 100).toInt()}%"),
              trailing: const Icon(Icons.chevron_right, size: 18),
              onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => TasbeehScreen(tasbeeh: item))),
            ),
          ),
        );
      },
    );
  }

  Widget _buildEmptyState() => Container(
      width: double.infinity,
      padding: const EdgeInsets.all(30),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(20)),
      child: Column(children: [
        Icon(Icons.spa_outlined, size: 50, color: Colors.brown[200]),
        const SizedBox(height: 10),
        Text("No Tasbeehs yet", style: GoogleFonts.poppins(color: Colors.grey))
      ]));

  Widget _noFilterResults() => Padding(
      padding: const EdgeInsets.symmetric(vertical: 20),
      child: Text("No $_filter Tasbeehs found."));

  Widget _actionCard(String title, IconData icon, VoidCallback onTap) =>
      ListTile(
          tileColor: Colors.white,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          leading: Icon(icon, color: const Color(0xFF4A3728)),
          title: Text(title,
              style: GoogleFonts.poppins(fontWeight: FontWeight.w500)),
          trailing: const Icon(Icons.add, size: 20),
          onTap: onTap);
}
