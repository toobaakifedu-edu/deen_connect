import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// 1. Model Class ko yahan define kar diya taake "Undefined class" error khatam ho jaye
class AllahName {
  final int id;
  final String arabic;
  final String transliteration;
  final String meaning;

  AllahName({
    required this.id,
    required this.arabic,
    required this.transliteration,
    required this.meaning,
  });
}

class AllahNamesScreen extends StatefulWidget {
  const AllahNamesScreen({super.key});

  @override
  State<AllahNamesScreen> createState() => _AllahNamesScreenState();
}

class _AllahNamesScreenState extends State<AllahNamesScreen> {
  // Aapki complete 99 names ki list
  final List<AllahName> allNames = [
    AllahName(
        id: 1,
        arabic: "ٱلرَّحْمَٰنُ",
        transliteration: "Ar-Rahman",
        meaning: "The Most Merciful"),
    AllahName(
        id: 2,
        arabic: "ٱلرَّحِيمُ",
        transliteration: "Ar-Raheem",
        meaning: "The Most Kind"),
    AllahName(
        id: 3,
        arabic: "ٱلْمَلِكُ",
        transliteration: "Al-Malik",
        meaning: "The Sovereign Lord"),
    AllahName(
        id: 4,
        arabic: "ٱلْقُدُّوسُ",
        transliteration: "Al-Quddus",
        meaning: "The Holy"),
    AllahName(
        id: 5,
        arabic: "ٱلسَّلَامُ",
        transliteration: "As-Salam",
        meaning: "The Source of Peace"),
    AllahName(
        id: 6,
        arabic: "ٱلْمُؤْمِنُ",
        transliteration: "Al-Mu'min",
        meaning: "The Guardian of Faith"),
    AllahName(
        id: 7,
        arabic: "ٱلْمُهَيْمِنُ",
        transliteration: "Al-Muhaymin",
        meaning: "The Protector"),
    AllahName(
        id: 8,
        arabic: "ٱلْعَزِيزُ",
        transliteration: "Al-Aziz",
        meaning: "The Mighty"),
    AllahName(
        id: 9,
        arabic: "ٱلْجَبَّارُ",
        transliteration: "Al-Jabbar",
        meaning: "The Compeller"),
    AllahName(
        id: 10,
        arabic: "ٱلْمُتَكَبِّرُ",
        transliteration: "Al-Mutakabbir",
        meaning: "The Majestic"),
    AllahName(
        id: 11,
        arabic: "ٱلْخَالِقُ",
        transliteration: "Al-Khaliq",
        meaning: "The Creator"),
    AllahName(
        id: 12,
        arabic: "ٱلْبَارِئُ",
        transliteration: "Al-Bari'",
        meaning: "The Evolver"),
    AllahName(
        id: 13,
        arabic: "ٱلْمُصَوِّرُ",
        transliteration: "Al-Musawwir",
        meaning: "The Fashioner"),
    AllahName(
        id: 14,
        arabic: "ٱلْغَفَّارُ",
        transliteration: "Al-Ghaffar",
        meaning: "The Constant Forgiver"),
    AllahName(
        id: 15,
        arabic: "ٱلْقَهَّارُ",
        transliteration: "Al-Qahhar",
        meaning: "The All-Prevailing One"),
    AllahName(
        id: 16,
        arabic: "ٱلْوَهَّابُ",
        transliteration: "Al-Wahhab",
        meaning: "The Supreme Bestower"),
    AllahName(
        id: 17,
        arabic: "ٱلرَّزَّاقُ",
        transliteration: "Ar-Razzaq",
        meaning: "The Provider"),
    AllahName(
        id: 18,
        arabic: "ٱلْفَتَّاحُ",
        transliteration: "Al-Fattah",
        meaning: "The Opener"),
    AllahName(
        id: 19,
        arabic: "ٱلْعَلِيمُ",
        transliteration: "Al-Alim",
        meaning: "The All-Knowing One"),
    AllahName(
        id: 20,
        arabic: "ٱلْقَابِضُ",
        transliteration: "Al-Qabid",
        meaning: "The Withholder"),
    AllahName(
        id: 21,
        arabic: "ٱلْبَاسِطُ",
        transliteration: "Al-Basit",
        meaning: "The Extender"),
    AllahName(
        id: 22,
        arabic: "ٱلْخَافِضُ",
        transliteration: "Al-Khafid",
        meaning: "The Abaser"),
    AllahName(
        id: 23,
        arabic: "ٱلرَّافِعُ",
        transliteration: "Ar-Rafi'",
        meaning: "The Exalter"),
    AllahName(
        id: 24,
        arabic: "ٱلْمُعِزُّ",
        transliteration: "Al-Mu'izz",
        meaning: "The Giver of Honor"),
    AllahName(
        id: 25,
        arabic: "ٱلْمُذِلُّ",
        transliteration: "Al-Mudhill",
        meaning: "The Giver of Dishonor"),
    AllahName(
        id: 26,
        arabic: "ٱلسَّمِيعُ",
        transliteration: "As-Sami'",
        meaning: "The All-Hearing"),
    AllahName(
        id: 27,
        arabic: "ٱلْبَصِيرُ",
        transliteration: "Al-Basir",
        meaning: "The All-Seeing"),
    AllahName(
        id: 28,
        arabic: "ٱلْحَكَمُ",
        transliteration: "Al-Hakam",
        meaning: "The Judge"),
    AllahName(
        id: 29,
        arabic: "ٱلْعَدْلُ",
        transliteration: "Al-Adl",
        meaning: "The Just"),
    AllahName(
        id: 30,
        arabic: "ٱللَّطِيفُ",
        transliteration: "Al-Latif",
        meaning: "The Subtle One"),
    AllahName(
        id: 31,
        arabic: "ٱلْخَبِيرُ",
        transliteration: "Al-Khabir",
        meaning: "The All-Aware"),
    AllahName(
        id: 32,
        arabic: "ٱلْحَلِيمُ",
        transliteration: "Al-Halim",
        meaning: "The Forbearing"),
    AllahName(
        id: 33,
        arabic: "ٱلْعَظِيمُ",
        transliteration: "Al-Azim",
        meaning: "The Magnificent"),
    AllahName(
        id: 34,
        arabic: "ٱلْغَفُورُ",
        transliteration: "Al-Ghafur",
        meaning: "The Forgiving"),
    AllahName(
        id: 35,
        arabic: "ٱلشَّكُورُ",
        transliteration: "Ash-Shakur",
        meaning: "The Appreciative"),
    AllahName(
        id: 36,
        arabic: "ٱلْعَلِيُّ",
        transliteration: "Al-Aliy",
        meaning: "The Highest"),
    AllahName(
        id: 37,
        arabic: "ٱلْكَبِيرُ",
        transliteration: "Al-Kabir",
        meaning: "The Greatest"),
    AllahName(
        id: 38,
        arabic: "ٱلْحَفِيظُ",
        transliteration: "Al-Hafiz",
        meaning: "The Preserver"),
    AllahName(
        id: 39,
        arabic: "ٱلْمُقِيتُ",
        transliteration: "Al-Muqit",
        meaning: "The Sustainer"),
    AllahName(
        id: 40,
        arabic: "ٱلْحَسِيبُ",
        transliteration: "Al-Hasib",
        meaning: "The Reckoner"),
    AllahName(
        id: 41,
        arabic: "ٱلْجَلِيلُ",
        transliteration: "Al-Jalil",
        meaning: "The Majestic"),
    AllahName(
        id: 42,
        arabic: "ٱلْكَرِيمُ",
        transliteration: "Al-Karim",
        meaning: "The Generous"),
    AllahName(
        id: 43,
        arabic: "ٱلرَّقِيبُ",
        transliteration: "Ar-Raqib",
        meaning: "The Watchful"),
    AllahName(
        id: 44,
        arabic: "ٱلْمُجِيبُ",
        transliteration: "Al-Mujib",
        meaning: "The Responsive"),
    AllahName(
        id: 45,
        arabic: "ٱلْوَاسِعُ",
        transliteration: "Al-Wasi'",
        meaning: "The All-Pervading"),
    AllahName(
        id: 46,
        arabic: "ٱلْحَكِيمُ",
        transliteration: "Al-Hakim",
        meaning: "The Wise"),
    AllahName(
        id: 47,
        arabic: "ٱلْوَدُودُ",
        transliteration: "Al-Wadud",
        meaning: "The Loving One"),
    AllahName(
        id: 48,
        arabic: "ٱلْمَجِيدُ",
        transliteration: "Al-Majid",
        meaning: "The Glorious"),
    AllahName(
        id: 49,
        arabic: "ٱلْبَاعِثُ",
        transliteration: "Al-Ba'ith",
        meaning: "The Resurrector"),
    AllahName(
        id: 50,
        arabic: "ٱلشَّهِيدُ",
        transliteration: "Ash-Shahid",
        meaning: "The Witness"),
    AllahName(
        id: 51,
        arabic: "ٱلْحَقُّ",
        transliteration: "Al-Haqq",
        meaning: "The Truth"),
    AllahName(
        id: 52,
        arabic: "ٱلْوَكِيلُ",
        transliteration: "Al-Wakil",
        meaning: "The Trustee"),
    AllahName(
        id: 53,
        arabic: "ٱلْقَوِيُّ",
        transliteration: "Al-Qawiyy",
        meaning: "The Strong"),
    AllahName(
        id: 54,
        arabic: "ٱلْمَتِينُ",
        transliteration: "Al-Matin",
        meaning: "The Firm One"),
    AllahName(
        id: 55,
        arabic: "ٱلْوَلِيُّ",
        transliteration: "Al-Waliyy",
        meaning: "The Protecting Friend"),
    AllahName(
        id: 56,
        arabic: "ٱلْحَمِيدُ",
        transliteration: "Al-Hamid",
        meaning: "The Praiseworthy"),
    AllahName(
        id: 57,
        arabic: "ٱلْمُحْصِي",
        transliteration: "Al-Muhsi",
        meaning: "The Counter"),
    AllahName(
        id: 58,
        arabic: "ٱلْمُبْدِئُ",
        transliteration: "Al-Mubdi'",
        meaning: "The Originator"),
    AllahName(
        id: 59,
        arabic: "ٱلْمُعِيدُ",
        transliteration: "Al-Mu'id",
        meaning: "The Restorer"),
    AllahName(
        id: 60,
        arabic: "ٱلْمُحْيِي",
        transliteration: "Al-Muhyi",
        meaning: "The Giver of Life"),
    AllahName(
        id: 61,
        arabic: "ٱلْمُمِيتُ",
        transliteration: "Al-Mumit",
        meaning: "The Creator of Death"),
    AllahName(
        id: 62,
        arabic: "ٱلْحَيُّ",
        transliteration: "Al-Hayy",
        meaning: "The Ever-Living"),
    AllahName(
        id: 63,
        arabic: "ٱلْقَيُّومُ",
        transliteration: "Al-Qayyum",
        meaning: "The Self-Subsisting"),
    AllahName(
        id: 64,
        arabic: "ٱلْوَاجِدُ",
        transliteration: "Al-Wajid",
        meaning: "The Finder"),
    AllahName(
        id: 65,
        arabic: "ٱلْمَاجِدُ",
        transliteration: "Al-Majid",
        meaning: "The Noble"),
    AllahName(
        id: 66,
        arabic: "ٱلْوَاحِدُ",
        transliteration: "Al-Wahid",
        meaning: "The Unique One"),
    AllahName(
        id: 67,
        arabic: "ٱلْأَحَدُ",
        transliteration: "Al-Ahad",
        meaning: "The One"),
    AllahName(
        id: 68,
        arabic: "ٱلصَّمَدُ",
        transliteration: "As-Samad",
        meaning: "The Eternal"),
    AllahName(
        id: 69,
        arabic: "ٱلْقَادِرُ",
        transliteration: "Al-Qadir",
        meaning: "The Able"),
    AllahName(
        id: 70,
        arabic: "ٱلْمُقْتَدِرُ",
        transliteration: "Al-Muqtadir",
        meaning: "The Powerful"),
    AllahName(
        id: 71,
        arabic: "ٱلْمُقَدِّمُ",
        transliteration: "Al-Muqaddim",
        meaning: "The Expediter"),
    AllahName(
        id: 72,
        arabic: "ٱلْمُؤَخِّرُ",
        transliteration: "Al-Mu'akhkhir",
        meaning: "The Delayer"),
    AllahName(
        id: 73,
        arabic: "ٱلْأَوَّلُ",
        transliteration: "Al-Awwal",
        meaning: "The First"),
    AllahName(
        id: 74,
        arabic: "ٱلْآخِرُ",
        transliteration: "Al-Akhir",
        meaning: "The Last"),
    AllahName(
        id: 75,
        arabic: "ٱلظَّاهِرُ",
        transliteration: "Az-Zahir",
        meaning: "The Manifest"),
    AllahName(
        id: 76,
        arabic: "ٱلْبَاطِنُ",
        transliteration: "Al-Batin",
        meaning: "The Hidden"),
    AllahName(
        id: 77,
        arabic: "ٱلْوَالِي",
        transliteration: "Al-Wali",
        meaning: "The Governor"),
    AllahName(
        id: 78,
        arabic: "ٱلْمُتَعَالِي",
        transliteration: "Al-Muta'ali",
        meaning: "The Most Exalted"),
    AllahName(
        id: 79,
        arabic: "ٱلْبَرُّ",
        transliteration: "Al-Barr",
        meaning: "The Source of All Goodness"),
    AllahName(
        id: 80,
        arabic: "ٱلتَّوَّابُ",
        transliteration: "At-Tawwab",
        meaning: "The Accepter of Repentance"),
    AllahName(
        id: 81,
        arabic: "ٱلْمُنْتَقِمُ",
        transliteration: "Al-Muntaqim",
        meaning: "The Avenger"),
    AllahName(
        id: 82,
        arabic: "ٱلْعَفُوُّ",
        transliteration: "Al-Afuww",
        meaning: "The Pardoner"),
    AllahName(
        id: 83,
        arabic: "ٱلرَّؤُوفُ",
        transliteration: "Ar-Ra'uf",
        meaning: "The Compassionate"),
    AllahName(
        id: 84,
        arabic: "مَالِكُ ٱلْمُلْكِ",
        transliteration: "Malik-ul-Mulk",
        meaning: "The Owner of All Sovereignty"),
    AllahName(
        id: 85,
        arabic: "ذُو ٱلْجَلَالِ وَٱلْإِكْرَامِ",
        transliteration: "Dhul-Jalali wal-Ikram",
        meaning: "Lord of Majesty and Generosity"),
    AllahName(
        id: 86,
        arabic: "ٱلْمُقْسِطُ",
        transliteration: "Al-Muqsit",
        meaning: "The Equitable"),
    AllahName(
        id: 87,
        arabic: "ٱلْجَامِعُ",
        transliteration: "Al-Jami'",
        meaning: "The Gatherer"),
    AllahName(
        id: 88,
        arabic: "ٱلْغَنِيُّ",
        transliteration: "Al-Ghaniyy",
        meaning: "The Self-Sufficient"),
    AllahName(
        id: 89,
        arabic: "ٱلْمُغْنِي",
        transliteration: "Al-Mughni",
        meaning: "The Enricher"),
    AllahName(
        id: 90,
        arabic: "ٱلْمَانِعُ",
        transliteration: "Al-Mani'",
        meaning: "The Preventer"),
    AllahName(
        id: 91,
        arabic: "ٱلضَّارُّ",
        transliteration: "Ad-Darr",
        meaning: "The Distresser"),
    AllahName(
        id: 92,
        arabic: "ٱلنَّافِعُ",
        transliteration: "An-Nafi'",
        meaning: "The Propitious"),
    AllahName(
        id: 93,
        arabic: "ٱلنُّورُ",
        transliteration: "An-Nur",
        meaning: "The Light"),
    AllahName(
        id: 94,
        arabic: "ٱلْهَادِي",
        transliteration: "Al-Hadi",
        meaning: "The Guide"),
    AllahName(
        id: 95,
        arabic: "ٱلْبَدِيعُ",
        transliteration: "Al-Badi'",
        meaning: "The Incomparable"),
    AllahName(
        id: 96,
        arabic: "ٱلْبَاقِي",
        transliteration: "Al-Baqi",
        meaning: "The Everlasting"),
    AllahName(
        id: 97,
        arabic: "ٱلْوَارِثُ",
        transliteration: "Al-Warith",
        meaning: "The Ultimate Inheritor"),
    AllahName(
        id: 98,
        arabic: "ٱلرَّشِيدُ",
        transliteration: "Ar-Rashid",
        meaning: "The Guide to the Right Path"),
    AllahName(
        id: 99,
        arabic: "ٱلصَّبُورُ",
        transliteration: "As-Sabur",
        meaning: "The Patient One"),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFDF7F2),
      appBar: AppBar(
        title: Text("99 Names of Allah",
            style:
                GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 20)),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: const Color(0xFF4A3728),
      ),
      body: Column(
        children: [
          _buildTopBanner(),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.8,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
              ),
              itemCount: allNames.length,
              itemBuilder: (context, index) {
                final item = allNames[index];
                return _buildNameCard(item);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopBanner() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(20),
      width: double.infinity,
      decoration: BoxDecoration(
        color: const Color(0xFF4A3728),
        borderRadius: BorderRadius.circular(25),
      ),
      child: Column(
        children: [
          const Icon(Icons.auto_awesome, color: Colors.amber, size: 30),
          const SizedBox(height: 10),
          Text("Asma-ul-Husna",
              style: GoogleFonts.amiri(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.bold)),
          Text("Whoever commits them to memory will enter Paradise.",
              textAlign: TextAlign.center,
              style: GoogleFonts.poppins(color: Colors.white70, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _buildNameCard(AllahName item) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(25),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 15,
            offset: const Offset(0, 5),
          )
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            top: 10,
            left: 10,
            child: CircleAvatar(
              radius: 12,
              backgroundColor: const Color(0xFFFDF7F2),
              child: Text(item.id.toString(),
                  style: const TextStyle(fontSize: 10, color: Colors.brown)),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(height: 10),
                FittedBox(
                  child: Text(item.arabic,
                      style: GoogleFonts.amiri(
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                          color: const Color(0xFF4A3728))),
                ),
                const SizedBox(height: 8),
                Text(item.transliteration,
                    textAlign: TextAlign.center,
                    style: GoogleFonts.poppins(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Colors.brown[700])),
                const Divider(indent: 30, endIndent: 30, height: 20),
                Text(item.meaning,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    style: GoogleFonts.poppins(
                        fontSize: 11,
                        color: Colors.grey[600],
                        fontStyle: FontStyle.italic)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
