import 'package:flutter/material.dart';
import 'package:deen_connect/features/prayer_times/prayer_times_screen.dart';
import 'package:deen_connect/features/qibla/qibla_screen.dart';
import 'package:deen_connect/features/quran/quran_screen.dart';
import 'package:deen_connect/features/duas/duas_screen.dart';
import 'package:deen_connect/features/tracker/tracker_screen.dart';
import 'package:deen_connect/features/dashboard/dashboard_screen.dart'; // ✅ Dashboard Import kiya

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  // ✅ Yahan humne pehle screen ko DashboardScreen se replace kar diya hai
  final List<Widget> _screens = [
    const DashboardScreen(), // Ab Dashboard hi aapka main 'Home' hai
    const PrayerTimesScreen(),
    const QiblaScreen(),
    const QuranScreen(),
    const DuasScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Background color theme ke mutabiq rakha hai
      backgroundColor: const Color(0xFFFDF7F2),
      body: _screens[_selectedIndex],

      bottomNavigationBar: Container(
        margin: const EdgeInsets.fromLTRB(
            20, 0, 20, 20), // Bottom se thora upar professional look ke liye
        decoration: BoxDecoration(
          color: const Color(0xFF352924),
          borderRadius: BorderRadius.circular(30),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildNavItem(0, Icons.home_outlined, Icons.home, 'Home'),
                _buildNavItem(
                    1, Icons.access_time_outlined, Icons.access_time, 'Prayer'),
                _buildNavItem(
                    2, Icons.explore_outlined, Icons.explore, 'Qibla'),
                _buildNavItem(3, Icons.book_outlined, Icons.book, 'Quran'),
                _buildNavItem(
                    4, Icons.favorite_outline, Icons.favorite, 'Duas'),
              ],
            ),
          ),
        ),
      ),

      // Floating Action Button sirf Home/Dashboard par dikhayein agar Tracker check karna ho
      floatingActionButton: _selectedIndex == 0
          ? FloatingActionButton(
              mini: true,
              backgroundColor: const Color(0xFF4A3728),
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const TrackerScreen()));
              },
              child: const Icon(Icons.insights, color: Colors.white, size: 20),
            )
          : null,
    );
  }

  Widget _buildNavItem(
      int index, IconData icon, IconData activeIcon, String label) {
    final isActive = _selectedIndex == index;
    return GestureDetector(
      onTap: () => _onItemTapped(index),
      behavior: HitTestBehavior.opaque,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            isActive ? activeIcon : icon,
            color: isActive ? const Color(0xFFDBC1A3) : Colors.white70,
            size: 26,
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: isActive ? const Color(0xFFDBC1A3) : Colors.white70,
              fontSize: 10,
              fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}
