import 'package:dio/dio.dart';

class DynamoDbService {
  final String _endpoint =
      "https://your-api-gateway.amazonaws.com/prod/history";
  final Dio _dio = Dio();

  Future<void> syncToDynamo(List<Map<String, dynamic>> data) async {
    try {
      await _dio.post(_endpoint, data: {"items": data});
    } catch (e) {
      print("DynamoDB Sync Error: $e");
    }
  }
}
