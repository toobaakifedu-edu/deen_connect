class Hadith {
  final String collection; // Bukhari, Muslim etc
  final String hadithNumber;
  final String title;
  final String textArabic;
  final String textEnglish;
  final String textUrdu;

  Hadith({
    required this.collection,
    required this.hadithNumber,
    required this.title,
    required this.textArabic,
    required this.textEnglish,
    required this.textUrdu,
  });

  factory Hadith.fromJson(Map<String, dynamic> json) {
    return Hadith(
      collection: json['collection'] ?? '',
      hadithNumber: json['hadithNumber'] ?? '',
      title: json['title'] ?? '',
      textArabic: json['hadithArabic'] ?? '',
      textEnglish: json['hadithEnglish'] ?? '',
      textUrdu: json['hadithUrdu'] ?? '',
    );
  }
}
