import 'package:hive/hive.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

part 'tasbeeh_model.g.dart';

@HiveType(typeId: 0)
class Tasbeeh extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  String name;

  @HiveField(2)
  int currentCount;

  @HiveField(3)
  int targetCount;

  @HiveField(4)
  DateTime startDate;

  @HiveField(5)
  String durationType;

  @HiveField(6)
  int colorValue;

  @HiveField(7)
  bool isCompleted;

  Tasbeeh({
    required this.id,
    required this.name,
    this.currentCount = 0,
    required this.targetCount,
    required this.startDate,
    this.durationType = 'Daily',
    this.colorValue = 0xFF4A3728,
    this.isCompleted = false,
  });

  factory Tasbeeh.fromMap(Map<String, dynamic> map, String docId) {
    DateTime parseDate(dynamic date) {
      if (date is Timestamp) return date.toDate();
      if (date is String) return DateTime.tryParse(date) ?? DateTime.now();
      return DateTime.now();
    }

    return Tasbeeh(
      id: docId,
      name: map['name'] ?? '',
      currentCount: (map['currentCount'] ?? 0).toInt(),
      targetCount: (map['targetCount'] ?? 100).toInt(),
      startDate: parseDate(map['startDate']),
      durationType: map['durationType'] ?? 'Daily',
      colorValue: (map['colorValue'] ?? 0xFF4A3728).toInt(),
      isCompleted: map['isCompleted'] ?? false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'currentCount': currentCount,
      'targetCount': targetCount,
      'startDate': startDate,
      'durationType': durationType,
      'colorValue': colorValue,
      'isCompleted': isCompleted,
    };
  }
}
