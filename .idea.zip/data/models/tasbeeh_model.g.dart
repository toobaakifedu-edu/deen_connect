// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'tasbeeh_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class TasbeehAdapter extends TypeAdapter<Tasbeeh> {
  @override
  final int typeId = 0;

  @override
  Tasbeeh read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Tasbeeh(
      id: fields[0] as String,
      name: fields[1] as String,
      currentCount: fields[2] as int,
      targetCount: fields[3] as int,
      startDate: fields[4] as DateTime,
      durationType: fields[5] as String,
      colorValue: fields[6] as int,
      isCompleted: fields[7] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, Tasbeeh obj) {
    writer
      ..writeByte(8)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.currentCount)
      ..writeByte(3)
      ..write(obj.targetCount)
      ..writeByte(4)
      ..write(obj.startDate)
      ..writeByte(5)
      ..write(obj.durationType)
      ..writeByte(6)
      ..write(obj.colorValue)
      ..writeByte(7)
      ..write(obj.isCompleted);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is TasbeehAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
