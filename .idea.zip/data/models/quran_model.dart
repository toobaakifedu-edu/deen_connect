import 'package:flutter/material.dart';

class SurahModel {
  final int number;
  final List<AyahModel> ayahs;
  final String nameArabic;
  final String nameEnglish;

  SurahModel({
    required this.number,
    required this.ayahs,
    required this.nameArabic,
    required this.nameEnglish,
  });
}

class AyahModel {
  final int number;
  final String textArabic;
  final String textUrdu;

  AyahModel({
    required this.number,
    required this.textArabic,
    required this.textUrdu,
  });

  factory AyahModel.fromJson(Map<String, dynamic> json) {
    return AyahModel(
      // JSON keys check: Agar aapki JSON file mein keys mukhtalif hain
      // (jaise 'id', 'ar', 'ur'), toh ye logic unhe auto-handle kar lega.
      number: (json['verse'] ?? json['id'] ?? 0) as int,
      textArabic: (json['text'] ?? json['ar'] ?? "") as String,
      textUrdu: (json['translation'] ?? json['ur'] ?? "") as String,
    );
  }
}

/// Helper Class for Tajweed Rules
class TajweedParser {
  static List<TextSpan> parseTajweed(String text) {
    List<TextSpan> spans = [];

    // Filhal ye sirf simple text return kar raha hai.
    // Baad mein yahan RegEx ke zariye colors add kiye ja sakte hain.
    spans.add(TextSpan(
      text: text,
      style: const TextStyle(
        fontFamily: 'Uthmanic', // Ensure this font is in pubspec.yaml
        fontSize: 26,
        color: Colors.black,
      ),
    ));

    return spans;
  }
}
