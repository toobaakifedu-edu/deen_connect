import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'dart:async';

class SqfliteService {
  static final SqfliteService _instance = SqfliteService._internal();
  static Database? _database;

  factory SqfliteService() => _instance;

  SqfliteService._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDb();
    return _database!;
  }

  Future<Database> _initDb() async {
    String databasesPath = await getDatabasesPath();
    String path = join(databasesPath, "deen_history.db");

    return await openDatabase(
      path,
      version: 1,
      onCreate: (Database dbInstance, int version) async {
        await dbInstance.execute('''
          CREATE TABLE history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_name TEXT,
            timestamp TEXT,
            status TEXT,
            is_synced INTEGER DEFAULT 0  -- ✅ Ye column hona lazmi hai!
          )
        ''');
      },
    );
  }

  // Save karte waqt is_synced ko automatically 0 rakha jayega
  Future<void> saveHistory(String name, String status) async {
    final dbClient = await database;
    await dbClient.insert(
      'history',
      {
        'task_name': name,
        'timestamp': DateTime.now().toIso8601String(),
        'status': status,
        'is_synced': 0, // ✅ Naya data hamesha 0 (not synced) hoga
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, dynamic>>> getHistory() async {
    final dbClient = await database;
    return await dbClient.query('history', orderBy: 'id DESC');
  }
}
